"""Smart Lender - Intelligent Loan Risk Prediction System (Flask application)."""
import csv
import io
import json
import os
import secrets
import sys
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, Response, jsonify, redirect, render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from utils import config, db
from utils.formatting import inr
from utils.validation import password_errors, validate_prediction, validate_register

BASE = config.BASE_DIR
sys.path.insert(0, BASE)

app = Flask(__name__)
if not config.SECRET_KEY:
    print("WARNING: SECRET_KEY missing in .env - using a temporary key (sessions reset on restart).")
app.config.update(
    SECRET_KEY=config.SECRET_KEY or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=64 * 1024,
)
app.jinja_env.filters["inr"] = inr


# --------------------------------------------------------------------------- bootstrap
def bootstrap():
    """Create DB, dataset and trained models on first run, then seed sample data."""
    db.init_db()
    from ml import predict as ml_predict
    if not os.path.exists(os.path.join(BASE, "data", "loan_dataset.csv")):
        print("Generating synthetic dataset ...")
        import runpy
        runpy.run_path(os.path.join(BASE, "data", "generate_dataset.py"))
    if not ml_predict.models_ready():
        print("No trained models found - training all four models (one-time, ~10 seconds) ...")
        try:
            from ml import train_models
            train_models.main()
        except ModuleNotFoundError as e:
            sys.exit(f"\nMissing package: {e.name}. Run:  pip install -r requirements.txt\n")
        ml_predict.reset_cache()
    from utils.sample_data import seed_sample_data
    n = seed_sample_data()
    if n:
        print(f"Seeded {n} sample applications for {config.SEED_EMAIL}.")


# --------------------------------------------------------------------------- helpers
def current_user():
    uid = session.get("uid")
    return db.query("SELECT id, name, email, created_at FROM user WHERE id = ?", (uid,), one=True) if uid else None


def login_required_api(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("uid"):
            return jsonify(error="Please log in to continue."), 401
        return fn(*a, **kw)
    return wrapper


def login_required_page(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("uid") or not current_user():
            session.clear()
            return redirect(url_for("login_page", next=request.path))
        return fn(*a, **kw)
    return wrapper


def app_row_to_dict(r):
    d = dict(r)
    d["explanation"] = json.loads(d.pop("explanation_json")) if d.get("explanation_json") else None
    return d


def get_owned_application(app_id):
    return db.query("SELECT * FROM application WHERE id = ? AND user_id = ?",
                    (app_id, session["uid"]), one=True)


@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify(error="Not found."), 404
    return render_template("index.html", user=current_user(), not_found=True), 404


@app.errorhandler(413)
def too_large(e):
    return jsonify(error="Request too large."), 413


@app.errorhandler(500)
def server_error(e):
    if request.path.startswith("/api/"):
        return jsonify(error="Something went wrong on the server."), 500
    return "Something went wrong.", 500


# --------------------------------------------------------------------------- pages
@app.route("/")
def index():
    return render_template("index.html", user=current_user())


@app.route("/login")
def login_page():
    if session.get("uid"):
        return redirect(url_for("dashboard_page"))
    return render_template("login.html", user=None)


@app.route("/register")
def register_page():
    if session.get("uid"):
        return redirect(url_for("dashboard_page"))
    return render_template("register.html", user=None)


@app.route("/dashboard")
@login_required_page
def dashboard_page():
    return render_template("dashboard.html", user=current_user(), active="dashboard")


@app.route("/predict")
@login_required_page
def predict_page():
    return render_template("predict.html", user=current_user(), active="predict")


@app.route("/history")
@login_required_page
def history_page():
    return render_template("history.html", user=current_user(), active="history")


@app.route("/models")
@login_required_page
def models_page():
    return render_template("models.html", user=current_user(), active="models")


@app.route("/how-it-works")
def how_page():
    user = current_user()
    layout = "app_base.html" if user else "public_base.html"
    return render_template("how_it_works.html", user=user, active="how", layout=layout)


@app.route("/logout")
def logout_page():
    session.clear()
    return redirect(url_for("index"))


# --------------------------------------------------------------------------- auth API
@app.post("/api/register")
def api_register():
    clean, errors = validate_register(request.get_json(silent=True))
    if errors:
        return jsonify(error="Please fix the highlighted fields.", errors=errors), 400
    if db.query("SELECT id FROM user WHERE email = ?", (clean["email"],), one=True):
        return jsonify(error="That email is already registered.",
                       errors={"email": "That email is already registered."}), 409
    uid = db.execute("INSERT INTO user (name, email, password) VALUES (?,?,?)",
                     (clean["name"], clean["email"], generate_password_hash(clean["password"])))
    try:  # every new account starts with 5 clearly-labelled sample records
        from utils.sample_data import seed_starter_records
        seed_starter_records(uid)
    except Exception as exc:
        app.logger.warning("could not seed starter records: %s", exc)
    session.clear()
    session.permanent = True
    session["uid"] = uid
    return jsonify(message="Account created.", redirect=url_for("dashboard_page")), 201


@app.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or {}
    email, pw = str(data.get("email", "")).strip().lower(), str(data.get("password", ""))
    if not email or not pw:
        return jsonify(error="Email and password are required."), 400
    row = db.query("SELECT * FROM user WHERE email = ?", (email,), one=True)
    if not row or not check_password_hash(row["password"], pw):
        return jsonify(error="Incorrect email or password."), 401
    session.clear()
    session.permanent = True
    session["uid"] = row["id"]
    return jsonify(message="Logged in.", redirect=url_for("dashboard_page"))


@app.post("/api/quick-login")
def api_quick_login():
    from utils.sample_data import ensure_seed_user, seed_sample_data
    uid = ensure_seed_user()
    seed_sample_data()
    session.clear()
    session.permanent = True
    session["uid"] = uid
    return jsonify(message="Logged in.", redirect=url_for("dashboard_page"))


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(message="Logged out.")


# --------------------------------------------------------------------------- dashboard API
@app.get("/api/dashboard")
@login_required_api
def api_dashboard():
    uid = session["uid"]
    rows = db.query("SELECT prediction, risk_level, created_at FROM application WHERE user_id = ?", (uid,))
    today = datetime.now().strftime("%Y-%m-%d")
    low = sum(1 for r in rows if r["risk_level"] == "Low Risk")
    high = len(rows) - low
    today_n = sum(1 for r in rows if r["created_at"][:10] == today)

    # last 6 calendar months
    months, y, m = [], datetime.now().year, datetime.now().month
    for _ in range(6):
        months.append(f"{y}-{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    months.reverse()
    per_month = {k: {"total": 0, "repay": 0, "default": 0} for k in months}
    for r in rows:
        k = r["created_at"][:7]
        if k in per_month:
            per_month[k]["total"] += 1
            per_month[k]["repay" if r["prediction"] == "Likely to Repay" else "default"] += 1
    labels = [datetime.strptime(k, "%Y-%m").strftime("%b %Y") for k in months]

    comparison = None
    from ml import predict as ml_predict
    if ml_predict.models_ready():
        meta = ml_predict.load_metrics()
        comparison = {"labels": [meta["labels"][k] for k in meta["models"]],
                      "test_accuracy": [round(v["test_accuracy"] * 100, 1) for v in meta["models"].values()],
                      "selected": meta["selected_label"]}
    return jsonify(
        cards={"total": len(rows), "low_risk": low, "high_risk": high, "today": today_n},
        risk_distribution={"labels": ["Low Risk", "High Risk"], "values": [low, high]},
        monthly={"labels": labels, "values": [per_month[k]["total"] for k in months]},
        repay_vs_default={"labels": labels, "repay": [per_month[k]["repay"] for k in months],
                          "default": [per_month[k]["default"] for k in months]},
        model_comparison=comparison,
        recent=[app_row_to_dict(r) for r in db.query(
            "SELECT * FROM application WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 5", (uid,))],
    )


# --------------------------------------------------------------------------- prediction API
@app.post("/api/predict")
@login_required_api
def api_predict():
    data = request.get_json(silent=True)
    clean, errors = validate_prediction(data)
    if errors:
        return jsonify(error="Please fix the highlighted fields.", errors=errors), 400

    from ml import predict as ml_predict
    from ml.explain import explain
    if not ml_predict.models_ready():
        return jsonify(error="Models are not trained yet. Run: python ml/train_models.py"), 503
    try:
        res = ml_predict.predict(clean)
        pipe, _ = ml_predict.load_selected()
        expl = explain(pipe, res["frame"])
    except Exception as exc:  # never leak internals to the client
        app.logger.exception("prediction failed: %s", exc)
        return jsonify(error="Prediction failed. Please check the inputs and try again."), 500

    app_id = db.execute(
        """INSERT INTO application (user_id, applicant_name, gender, marital_status, dependents,
           education, self_employed, applicant_income, coapplicant_income, loan_amount, loan_term,
           credit_history, property_area, prediction, risk_level, model_used, prediction_probability,
           explanation_json, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (session["uid"], clean["applicant_name"], clean["gender"], clean["marital_status"],
         clean["dependents"], clean["education"], clean["self_employed"], clean["applicant_income"],
         clean["coapplicant_income"], clean["loan_amount"], clean["loan_term"], clean["credit_history"],
         clean["property_area"], res["prediction"], res["risk_level"], res["model_used"],
         res["probability"], json.dumps(expl) if expl else None,
         datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    out = {"application_id": app_id, "prediction": res["prediction"], "risk_level": res["risk_level"],
           "model_used": res["model_used"]}
    if res["probability"] is not None:
        out["probability"] = res["probability"]
    if expl:
        out["explanation"] = expl
    return jsonify(out), 201


# --------------------------------------------------------------------------- applications API
SORTABLE = {"id": "id", "applicant_name": "applicant_name COLLATE NOCASE", "loan_amount": "loan_amount",
            "prediction": "prediction", "risk_level": "risk_level", "model_used": "model_used",
            "created_at": "created_at"}


@app.get("/api/applications")
@login_required_api
def api_applications():
    q = request.args
    sql, args = "SELECT * FROM application WHERE user_id = ?", [session["uid"]]
    if q.get("q", "").strip():
        sql += " AND (applicant_name LIKE ? OR CAST(id AS TEXT) = ?)"
        args += [f"%{q['q'].strip()}%", q["q"].strip()]
    if q.get("risk") in ("Low Risk", "High Risk"):
        sql += " AND risk_level = ?"
        args.append(q["risk"])
    if q.get("prediction") in ("Likely to Repay", "Likely to Default"):
        sql += " AND prediction = ?"
        args.append(q["prediction"])
    if q.get("date_from"):
        sql += " AND date(created_at) >= date(?)"
        args.append(q["date_from"][:10])
    if q.get("date_to"):
        sql += " AND date(created_at) <= date(?)"
        args.append(q["date_to"][:10])
    col = SORTABLE.get(q.get("sort", "created_at"), "created_at")
    order = "ASC" if q.get("order") == "asc" else "DESC"
    sql += f" ORDER BY {col} {order}, id DESC"
    return jsonify(applications=[app_row_to_dict(r) for r in db.query(sql, args)])


@app.get("/api/applications/<int:app_id>")
@login_required_api
def api_application(app_id):
    row = get_owned_application(app_id)
    if not row:
        return jsonify(error="Application not found."), 404
    return jsonify(application=app_row_to_dict(row))


@app.delete("/api/applications/<int:app_id>")
@login_required_api
def api_delete_application(app_id):
    if not get_owned_application(app_id):
        return jsonify(error="Application not found."), 404
    db.execute("DELETE FROM application WHERE id = ? AND user_id = ?", (app_id, session["uid"]))
    return jsonify(message="Application deleted.")


# --------------------------------------------------------------------------- model performance API
@app.get("/api/model-performance")
@login_required_api
def api_model_performance():
    from ml import predict as ml_predict
    if not ml_predict.models_ready():
        return jsonify(error="Models are not trained yet. Run: python ml/train_models.py"), 503
    return jsonify(ml_predict.load_metrics())


# --------------------------------------------------------------------------- profile API
@app.get("/api/profile")
@login_required_api
def api_profile():
    u = current_user()
    return jsonify(profile={"name": u["name"], "email": u["email"], "member_since": u["created_at"][:10]})


@app.put("/api/profile")
@login_required_api
def api_update_profile():
    data = request.get_json(silent=True) or {}
    u = db.query("SELECT * FROM user WHERE id = ?", (session["uid"],), one=True)
    errors = {}
    if "name" in data:
        from utils.validation import NAME_RE
        name = str(data["name"]).strip()
        if not NAME_RE.match(name):
            errors["name"] = "Enter a valid name."
        else:
            db.execute("UPDATE user SET name = ? WHERE id = ?", (name, u["id"]))
    if data.get("new_password"):
        if not check_password_hash(u["password"], str(data.get("current_password", ""))):
            errors["current_password"] = "Current password is incorrect."
        else:
            errors.update(password_errors(str(data["new_password"]), "new_password"))
            if not errors:
                db.execute("UPDATE user SET password = ? WHERE id = ?",
                           (generate_password_hash(str(data["new_password"])), u["id"]))
    if errors:
        return jsonify(error="Please fix the highlighted fields.", errors=errors), 400
    return jsonify(message="Profile updated.")


# --------------------------------------------------------------------------- export + report
def _csv_safe(v):
    s = str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@") else s  # block spreadsheet formula injection


@app.get("/api/export/csv")
@login_required_api
def api_export_csv():
    rows = db.query("SELECT * FROM application WHERE user_id = ? ORDER BY created_at DESC, id DESC",
                    (session["uid"],))
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Application ID", "Applicant Name", "Loan Amount (INR)", "Prediction",
                "Risk Level", "Model", "Date"])
    for r in rows:
        w.writerow([r["id"], _csv_safe(r["applicant_name"]), int(r["loan_amount"]), r["prediction"],
                    r["risk_level"], r["model_used"], r["created_at"]])
    return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=smart_lender_applications.csv"})


@app.get("/api/report/<int:app_id>")
@login_required_api
def api_report(app_id):
    row = get_owned_application(app_id)
    if not row:
        return jsonify(error="Application not found."), 404
    from utils.pdf_report import build_report
    return Response(build_report(row), mimetype="application/pdf",
                    headers={"Content-Disposition": f"inline; filename=loan_risk_report_{app_id}.pdf"})


bootstrap()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=config.PORT, debug=config.DEBUG)
