/* Shared helpers for all Smart Lender pages */
const SL = {
  async api(url, opts = {}) {
    const o = { credentials: 'same-origin', headers: {}, ...opts };
    if (o.body && typeof o.body !== 'string') { o.body = JSON.stringify(o.body); o.headers['Content-Type'] = 'application/json'; }
    let res;
    try { res = await fetch(url, o); } catch (e) { throw { error: 'Network error. Is the server running?' }; }
    if (res.status === 401 && !url.includes('/api/login')) { location.href = '/login'; throw { error: 'Please log in.' }; }
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('json') ? await res.json() : null;
    if (!res.ok) throw data || { error: 'Request failed.' };
    return data;
  },
  // Indian digit grouping: 500000 -> ₹5,00,000
  inr(n) {
    if (n === null || n === undefined || isNaN(n)) return '—';
    return '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
  },
  esc(s) { const d = document.createElement('div'); d.textContent = s ?? ''; return d.innerHTML; },
  toast(msg, isErr = false) {
    let t = document.getElementById('toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast-x'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.toggle('err', isErr); t.classList.add('show');
    clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 3200);
  },
  riskPill(risk) { return `<span class="pill ${risk === 'Low Risk' ? 'pill-green' : 'pill-red'}">${SL.esc(risk)}</span>`; },
  predPill(p) { return `<span class="pill ${p === 'Likely to Repay' ? 'pill-green' : 'pill-red'}">${SL.esc(p)}</span>`; },
  fmtDate(s) { return s ? s.slice(0, 16).replace('T', ' ') : ''; },
  // Field-level errors: expects <input id=field> followed by <div class="field-error" data-for=field>
  showErrors(form, errors) {
    form.querySelectorAll('.is-invalid').forEach(e => e.classList.remove('is-invalid'));
    form.querySelectorAll('.field-error').forEach(e => { e.textContent = ''; e.classList.remove('show'); });
    let first = null;
    Object.entries(errors || {}).forEach(([k, msg]) => {
      const el = form.querySelector(`[name="${k}"]`); const box = form.querySelector(`.field-error[data-for="${k}"]`);
      if (el) { el.classList.add('is-invalid'); first = first || el; }
      if (box) { box.textContent = msg; box.classList.add('show'); }
    });
    if (first) first.focus();
  },
  initSidebar() {
    const b = document.getElementById('menuBtn'), s = document.getElementById('sidebar');
    if (b && s) b.addEventListener('click', () => s.classList.toggle('open'));
  },
  async logout() { try { await SL.api('/api/logout', { method: 'POST' }); } catch (e) {} location.href = '/'; },
  chartDefaults() {
    if (!window.Chart) return false;
    Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
    Chart.defaults.color = '#64748b';
    return true;
  },
  noChart(canvas) {
    const p = canvas.parentElement;
    p.innerHTML = '<div class="text-muted small p-3">Chart library could not load (internet needed for Chart.js CDN).</div>';
  },
};
document.addEventListener('DOMContentLoaded', SL.initSidebar);
