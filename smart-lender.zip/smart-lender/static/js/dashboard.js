(async function () {
  // ---------- EMI calculator (standalone; not an ML feature) ----------
  const P = document.getElementById('emiP'), R = document.getElementById('emiR'), N = document.getElementById('emiN');
  function emi() {
    const p = parseFloat(P.value), r = parseFloat(R.value), y = parseFloat(N.value);
    const out = document.getElementById('emiOut'), more = document.getElementById('emiMore');
    if (!(p > 0) || !(y > 0) || !(r >= 0)) { out.textContent = '–'; more.textContent = 'Enter valid positive values.'; return; }
    const n = Math.round(y * 12), i = r / 12 / 100;
    const e = i === 0 ? p / n : p * i * Math.pow(1 + i, n) / (Math.pow(1 + i, n) - 1);
    out.textContent = SL.inr(Math.round(e));
    more.textContent = `Total payable ${SL.inr(Math.round(e * n))} · interest ${SL.inr(Math.round(e * n - p))} over ${n} months`;
  }
  [P, R, N].forEach(el => el.addEventListener('input', emi)); emi();

  // ---------- profile + password ----------
  document.getElementById('profileForm').addEventListener('submit', async (e) => {
    e.preventDefault(); const f = e.target;
    try { await SL.api('/api/profile', { method: 'PUT', body: { name: f.name.value.trim() } }); SL.toast('Profile updated.'); SL.showErrors(f, {}); }
    catch (err) { SL.showErrors(f, err.errors || {}); SL.toast(err.error || 'Update failed.', true); }
  });
  document.getElementById('pwForm').addEventListener('submit', async (e) => {
    e.preventDefault(); const f = e.target;
    if (!f.current_password.value || !f.new_password.value) { SL.showErrors(f, { current_password: f.current_password.value ? '' : 'Enter your current password.', new_password: f.new_password.value ? '' : 'Enter a new password.' }); return; }
    try { await SL.api('/api/profile', { method: 'PUT', body: { current_password: f.current_password.value, new_password: f.new_password.value } }); SL.toast('Password changed.'); f.reset(); SL.showErrors(f, {}); }
    catch (err) { SL.showErrors(f, err.errors || {}); SL.toast(err.error || 'Could not change password.', true); }
  });

  // ---------- dashboard data ----------
  let d;
  try { d = await SL.api('/api/dashboard'); } catch (e) { SL.toast(e.error || 'Could not load dashboard.', true); return; }
  document.getElementById('cTotal').textContent = d.cards.total;
  document.getElementById('cLow').textContent = d.cards.low_risk;
  document.getElementById('cHigh').textContent = d.cards.high_risk;
  document.getElementById('cToday').textContent = d.cards.today;

  const body = document.getElementById('recentBody');
  body.innerHTML = d.recent.length ? d.recent.map(a => `<tr>
      <td>#${a.id}</td><td>${SL.esc(a.applicant_name)}</td><td>${SL.riskPill(a.risk_level)}</td>
      <td><a class="btn btn-outline-soft btn-sm" target="_blank" href="/api/report/${a.id}"><i class="bi bi-file-earmark-pdf"></i> PDF</a></td></tr>`).join('')
    : '<tr><td colspan="4" class="text-muted">No applications yet. Create your first prediction.</td></tr>';

  if (!SL.chartDefaults()) { document.querySelectorAll('canvas').forEach(SL.noChart); return; }
  const GREEN = '#10b981', RED = '#ef4444', BLUE = '#2563eb', CYAN = '#06b6d4';
  new Chart(chRisk, { type: 'doughnut', data: { labels: d.risk_distribution.labels, datasets: [{ data: d.risk_distribution.values, backgroundColor: [GREEN, RED], borderWidth: 0 }] },
    options: { maintainAspectRatio: false, cutout: '65%', plugins: { legend: { position: 'bottom' } } } });
  new Chart(chMonthly, { type: 'line', data: { labels: d.monthly.labels, datasets: [{ label: 'Applications', data: d.monthly.values, borderColor: BLUE, backgroundColor: 'rgba(37,99,235,.12)', fill: true, tension: .35, pointRadius: 4 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
  new Chart(chRvD, { type: 'bar', data: { labels: d.repay_vs_default.labels, datasets: [
      { label: 'Likely to Repay', data: d.repay_vs_default.repay, backgroundColor: GREEN, borderRadius: 6 },
      { label: 'Likely to Default', data: d.repay_vs_default.default, backgroundColor: RED, borderRadius: 6 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } } } });
  if (d.model_comparison) {
    const mc = d.model_comparison;
    new Chart(chModels, { type: 'bar', data: { labels: mc.labels, datasets: [{ data: mc.test_accuracy, borderRadius: 8,
        backgroundColor: mc.labels.map(l => l === mc.selected ? BLUE : '#cbd5e1') }] },
      options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 100 } } } });
  } else { chModels.parentElement.innerHTML = '<div class="text-muted small p-3">Models not trained yet.</div>'; }
})();
