(function () {
  const form = document.getElementById('predForm'), loader = document.getElementById('loader');
  const formView = document.getElementById('formView'), resultView = document.getElementById('resultView');
  const lw = document.getElementById('loanWords');

  const SAMPLE = { applicant_name: 'Rahul', gender: 'Male', marital_status: 'Married', dependents: '1', education: 'Graduate',
    self_employed: 'Salaried', applicant_income: 50000, coapplicant_income: 20000, loan_amount: 500000, loan_term: 360,
    credit_history: 'Good', property_area: 'Urban' };
  document.getElementById('fillSample').addEventListener('click', () => {
    Object.entries(SAMPLE).forEach(([k, v]) => form[k].value = v); SL.showErrors(form, {}); showWords();
    SL.toast('Sample values loaded.');
  });
  function showWords() { const v = parseFloat(form.loan_amount.value); lw.textContent = v > 0 ? SL.inr(v) : ''; }
  form.loan_amount.addEventListener('input', showWords);

  function clientValidate(d) {
    const e = {}, req = (k, m) => { if (!String(d[k] ?? '').trim()) e[k] = m; };
    if (!d.applicant_name.trim()) e.applicant_name = 'Applicant name is required.';
    else if (!/^[A-Za-z][A-Za-z .'\-]{1,79}$/.test(d.applicant_name.trim())) e.applicant_name = 'Enter a valid name (letters only).';
    [['gender', 'Select a gender.'], ['marital_status', 'Select marital status.'], ['dependents', 'Select dependents.'], ['education', 'Select education.'],
     ['self_employed', 'Select employment status.'], ['credit_history', 'Select credit history.'], ['property_area', 'Select property area.']].forEach(([k, m]) => req(k, m));
    const num = (k, label, min, required) => {
      const raw = String(d[k]).trim();
      if (raw === '') { if (required) e[k] = label + ' is required.'; return; }
      const v = Number(raw);
      if (isNaN(v)) e[k] = label + ' must be a number.';
      else if (v < 0) e[k] = label + ' cannot be negative.';
      else if (v < min) e[k] = `${label} must be at least ${min}.`;
    };
    num('applicant_income', 'Applicant income', 1, true); num('coapplicant_income', 'Co-applicant income', 0, false);
    num('loan_amount', 'Loan amount', 1000, true); num('loan_term', 'Loan term', 6, true);
    if (!e.loan_term && (Number(d.loan_term) > 480 || !Number.isInteger(Number(d.loan_term)))) e.loan_term = 'Loan term must be a whole number of months (6–480).';
    return e;
  }

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(form)); const errs = clientValidate(d);
    SL.showErrors(form, errs); if (Object.keys(errs).length) { SL.toast('Please fix the highlighted fields.', true); return; }
    loader.classList.add('show');
    const started = Date.now();
    try {
      const r = await SL.api('/api/predict', { method: 'POST', body: d });
      await new Promise(res => setTimeout(res, Math.max(0, 900 - (Date.now() - started)))); // let the animation be seen
      render(r, d);
    } catch (err) {
      if (err.errors) SL.showErrors(form, err.errors);
      SL.toast(err.error || 'Prediction failed.', true);
    } finally { loader.classList.remove('show'); }
  });

  function render(r, d) {
    const repay = r.prediction === 'Likely to Repay', cls = repay ? 'low' : 'high';
    const prob = (r.probability !== undefined) ? `<div class="kv"><div class="k">Repayment probability</div><div class="v">${(r.probability * 100).toFixed(1)}%</div></div>` : '';
    let expl = '';
    if (r.explanation && r.explanation.features && r.explanation.features.length) {
      const max = Math.max(...r.explanation.features.map(f => f.importance)) || 1;
      expl = `<div class="px-4 pb-3"><h3 class="h6 mt-2">Why did the model make this prediction?</h3>
        <p class="small text-muted mb-2">Method: ${SL.esc(r.explanation.method)}</p>` +
        r.explanation.features.map(f => `<div class="bar-row"><div>${SL.esc(f.feature)}</div>
          <div class="bar-track"><div class="bar-fill ${f.direction ? (f.direction.includes('repay') ? 'pos' : 'neg') : ''}" style="width:${Math.max(4, f.importance / max * 100)}%"></div></div>
          <div class="text-end small">${(f.importance * 100).toFixed(0)}%</div></div>
          ${f.direction ? `<div class="small text-muted" style="margin:-.35rem 0 .5rem 150px;padding-left:.8rem">${SL.esc(f.direction)}</div>` : ''}`).join('') +
        (r.explanation.kind === 'local' ? '<p class="small text-muted mt-2 mb-0">Bars show each input\'s share of the model\'s explained effect for this applicant.</p>'
          : '<p class="small text-muted mt-2 mb-0">These are the model\'s overall important features, not specific to this applicant.</p>') + '</div>';
    } else {
      expl = '<div class="px-4 pb-3 small text-muted">The prediction is influenced by the applicant\'s submitted financial and credit-related information. A detailed feature explanation is not available for this model.</div>';
    }
    const alertBox = repay
      ? `<div class="alert-x low"><i class="bi bi-check-circle-fill fs-4"></i><div><b>Low Risk Prediction</b><br>The model predicts a lower likelihood of default based on the submitted information.</div></div>`
      : `<div class="alert-x high"><i class="bi bi-exclamation-triangle-fill fs-4"></i><div><b>High Risk Prediction</b><br>Additional verification may be appropriate before making a lending decision.</div></div>`;
    resultView.innerHTML = `
      <div class="result-card">
        <div class="result-head ${cls}"><div class="small fw-semibold" style="letter-spacing:.12em;opacity:.9">LOAN RISK RESULT</div>
          <div class="big">${SL.esc(r.prediction.toUpperCase())}</div>
          <div class="opacity-75">${SL.esc(d.applicant_name)} · ${SL.inr(d.loan_amount)} over ${SL.esc(d.loan_term)} months</div></div>
        <div class="result-grid">
          <div class="kv"><div class="k">Prediction</div><div class="v">${SL.esc(r.prediction)}</div></div>
          <div class="kv"><div class="k">Risk Level</div><div class="v">${SL.esc(r.risk_level.toUpperCase())}</div></div>
          <div class="kv"><div class="k">Model Used</div><div class="v">${SL.esc(r.model_used)}</div></div>${prob}
        </div>
        ${alertBox}${expl}
        <div class="px-4 pb-3 d-flex flex-wrap gap-2">
          <button class="btn btn-outline-soft" disabled><i class="bi bi-check2-circle text-success me-1"></i>Application Saved (#${r.application_id})</button>
          <a class="btn btn-brand" target="_blank" href="/api/report/${r.application_id}"><i class="bi bi-file-earmark-pdf me-1"></i>Generate PDF Report</a>
          <button class="btn btn-outline-soft" id="again"><i class="bi bi-plus-circle me-1"></i>New Prediction</button>
          <a class="btn btn-outline-soft" href="/history"><i class="bi bi-clock-history me-1"></i>View History</a>
        </div>
        <div class="disclaimer">This prediction is intended to support loan risk assessment and does not constitute automatic loan approval or rejection.</div>
      </div>`;
    formView.style.display = 'none'; resultView.style.display = 'block'; window.scrollTo({ top: 0, behavior: 'smooth' });
    document.getElementById('again').addEventListener('click', () => {
      form.reset(); form.coapplicant_income.value = 0; form.loan_term.value = 360; lw.textContent = '';
      resultView.style.display = 'none'; formView.style.display = 'block'; window.scrollTo({ top: 0 });
    });
  }
})();
