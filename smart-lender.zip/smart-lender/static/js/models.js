(async function () {
  const root = document.getElementById('mpRoot');
  let m;
  try { m = await SL.api('/api/model-performance'); }
  catch (e) { root.innerHTML = `<div class="card-x text-danger">${SL.esc(e.error || 'Could not load metrics.')}</div>`; return; }

  const keys = Object.keys(m.models), pct = (v) => (v * 100).toFixed(1) + '%';
  const sel = m.selected_model, selLabel = m.selected_label, cm = m.models[sel].confusion_matrix;
  const trained = new Date(m.trained_at).toLocaleString('en-IN');

  const cards = keys.map(k => { const r = m.models[k]; const best = k === sel; return `
    <div class="col-sm-6 col-xl-3"><div class="card-x model-card h-100 ${best ? 'selected' : ''}">
      <div class="d-flex justify-content-between align-items-start mb-2"><h3 class="mb-0">${SL.esc(m.labels[k])}</h3>${best ? '<span class="tag-best">SELECTED</span>' : ''}</div>
      <div class="fs-2 fw-bold ${best ? 'text-primary' : ''}">${pct(r.test_accuracy)}</div><div class="small text-muted mb-2">Testing accuracy</div>
      <div class="metric-mini"><span>Training accuracy</span><b>${pct(r.train_accuracy)}</b></div>
      <div class="metric-mini"><span>Precision</span><b>${pct(r.precision)}</b></div>
      <div class="metric-mini"><span>Recall</span><b>${pct(r.recall)}</b></div>
      <div class="metric-mini border-0"><span>F1 score</span><b>${pct(r.f1_score)}</b></div>
    </div></div>`; }).join('');

  const rows = keys.map(k => { const r = m.models[k]; return `<tr class="${k === sel ? 'table-active' : ''}">
    <td><b>${SL.esc(m.labels[k])}</b>${k === sel ? '<span class="tag-best">SELECTED</span>' : ''}</td>
    <td>${pct(r.train_accuracy)}</td><td>${pct(r.test_accuracy)}</td><td>${pct(r.precision)}</td><td>${pct(r.recall)}</td><td>${pct(r.f1_score)}</td></tr>`; }).join('');

  const xg = m.models.xgboost;
  const why = sel === 'xgboost'
    ? `We evaluated four Machine Learning algorithms on our dataset. XGBoost achieved the best performance in our experiment, so it was selected as the final prediction model.`
    : `We evaluated four Machine Learning algorithms on our dataset. In this run, ${SL.esc(selLabel)} achieved the best test accuracy (XGBoost: ${pct(xg.test_accuracy)} vs ${pct(m.models[sel].test_accuracy)}), so it was selected as the final prediction model.`;

  root.innerHTML = `
    <div class="row g-3 mb-3">${cards}</div>

    <div class="card-x mb-3"><h2>Comparison Table</h2>
      <div class="table-wrap"><table class="table-x"><thead><tr><th>Model</th><th>Training Accuracy</th><th>Testing Accuracy</th><th>Precision</th><th>Recall</th><th>F1 Score</th></tr></thead><tbody>${rows}</tbody></table></div>
      <p class="small text-muted mt-2 mb-0">Precision, recall and F1 are for the "Likely to Repay" class, computed on ${m.test_rows} held-out test applicants (${m.train_rows} used for training; random_state ${m.random_state}). Trained ${SL.esc(trained)}.</p></div>

    <div class="row g-3 mb-3">
      <div class="col-lg-7"><div class="card-x h-100"><h2>Model Comparison</h2><div class="chart-box"><canvas id="mpChart"></canvas></div></div></div>
      <div class="col-lg-5"><div class="card-x h-100"><h2>Confusion Matrix — ${SL.esc(selLabel)}</h2>
        <div class="confusion">
          <div></div><div class="hd">Predicted: Default</div><div class="hd">Predicted: Repay</div>
          <div class="hd">Actual: Default</div><div class="cell cm-good">${cm.tn}</div><div class="cell cm-bad">${cm.fp}</div>
          <div class="hd">Actual: Repay</div><div class="cell cm-bad">${cm.fn}</div><div class="cell cm-good">${cm.tp}</div>
        </div>
        <p class="small text-muted mt-3 mb-0">Counts on the held-out test set. Green = correct predictions.</p></div></div>
    </div>

    <div class="card-x"><h2>Why was ${SL.esc(selLabel)} selected?</h2><p class="mb-0">${why}</p>
      <p class="small text-muted mt-2 mb-0">The best model can differ on other datasets; this selection reflects only this experiment.</p></div>`;

  if (!SL.chartDefaults()) { SL.noChart(document.getElementById('mpChart')); return; }
  new Chart(document.getElementById('mpChart'), { type: 'bar', data: { labels: keys.map(k => m.labels[k]), datasets: [
      { label: 'Testing accuracy', data: keys.map(k => +(m.models[k].test_accuracy * 100).toFixed(1)), backgroundColor: keys.map(k => k === sel ? '#2563eb' : '#93c5fd'), borderRadius: 8 },
      { label: 'F1 score', data: keys.map(k => +(m.models[k].f1_score * 100).toFixed(1)), backgroundColor: '#06b6d4', borderRadius: 8 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, scales: { y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%' } } } } });
})();
