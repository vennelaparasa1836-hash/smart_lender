(function () {
  const state = { sort: 'created_at', order: 'desc' };
  const $ = (id) => document.getElementById(id);
  let timer;

  async function load() {
    const p = new URLSearchParams({ sort: state.sort, order: state.order });
    if ($('fQ').value.trim()) p.set('q', $('fQ').value.trim());
    if ($('fRisk').value) p.set('risk', $('fRisk').value);
    if ($('fPred').value) p.set('prediction', $('fPred').value);
    if ($('fFrom').value) p.set('date_from', $('fFrom').value);
    if ($('fTo').value) p.set('date_to', $('fTo').value);
    try {
      const { applications: rows } = await SL.api('/api/applications?' + p);
      $('hBody').innerHTML = rows.length ? rows.map(a => `<tr>
        <td>#${a.id}</td>
        <td>${SL.esc(a.applicant_name)}</td>
        <td>${SL.inr(a.loan_amount)}</td><td>${SL.predPill(a.prediction)}</td><td>${SL.riskPill(a.risk_level)}</td>
        <td>${SL.esc(a.model_used)}</td><td class="text-nowrap">${SL.fmtDate(a.created_at)}</td>
        <td class="text-nowrap">
          <button class="btn btn-outline-soft btn-sm" data-view="${a.id}" title="View"><i class="bi bi-eye"></i></button>
          <a class="btn btn-outline-soft btn-sm" target="_blank" href="/api/report/${a.id}" title="Generate report"><i class="bi bi-file-earmark-pdf"></i></a>
          <button class="btn btn-outline-danger btn-sm" data-del="${a.id}" title="Delete"><i class="bi bi-trash"></i></button>
        </td></tr>`).join('') : '<tr><td colspan="8" class="text-muted p-4 text-center">No applications match your filters.</td></tr>';
      $('hCount').textContent = `${rows.length} application${rows.length === 1 ? '' : 's'}`;
    } catch (e) { SL.toast(e.error || 'Could not load applications.', true); }
  }

  function row(k, v) { return `<div class="col-6 col-md-4"><div class="kv"><div class="k">${k}</div><div class="v fs-6">${v}</div></div></div>`; }
  async function view(id) {
    try {
      const { application: a } = await SL.api('/api/applications/' + id);
      $('vTitle').innerHTML = `Application #${a.id}`;
      $('vPdf').href = '/api/report/' + a.id;
      const e = a.explanation;
      $('vBody').innerHTML = `
        <div class="p-3 rounded-3 mb-3 ${a.risk_level === 'Low Risk' ? 'alert-x low' : 'alert-x high'}" style="margin:0 0 1rem">
          <div><div class="fw-bold fs-5">${SL.esc(a.prediction.toUpperCase())} · ${SL.esc(a.risk_level.toUpperCase())}</div>
          <div class="small">Model: ${SL.esc(a.model_used)}${a.prediction_probability !== null ? ` · Repayment probability ${(a.prediction_probability * 100).toFixed(1)}%` : ''}</div></div></div>
        <h6>Applicant</h6><div class="row g-3 mb-3">${row('Name', SL.esc(a.applicant_name))}${row('Gender', SL.esc(a.gender))}${row('Marital status', SL.esc(a.marital_status))}
          ${row('Dependents', SL.esc(a.dependents))}${row('Education', SL.esc(a.education))}${row('Employment', SL.esc(a.self_employed))}</div>
        <h6>Loan &amp; credit</h6><div class="row g-3 mb-3">${row('Applicant income', SL.inr(a.applicant_income) + '/mo')}${row('Co-applicant income', SL.inr(a.coapplicant_income) + '/mo')}
          ${row('Loan amount', SL.inr(a.loan_amount))}${row('Loan term', a.loan_term + ' months')}${row('Credit history', SL.esc(a.credit_history))}${row('Property area', SL.esc(a.property_area))}</div>
        ${e && e.features ? `<h6>Important features <small class="text-muted fw-normal">(${SL.esc(e.method)})</small></h6>` +
          e.features.map(f => `<div class="bar-row"><div>${SL.esc(f.feature)}</div><div class="bar-track"><div class="bar-fill ${f.direction ? (f.direction.includes('repay') ? 'pos' : 'neg') : ''}" style="width:${Math.max(4, f.importance / e.features[0].importance * 100)}%"></div></div><div class="text-end small">${(f.importance * 100).toFixed(0)}%</div></div>`).join('') : ''}
        <p class="small text-muted mt-3 mb-0">Date: ${SL.fmtDate(a.created_at)}. This prediction supports loan risk assessment and does not constitute automatic loan approval or rejection.</p>`;
      new bootstrap.Modal($('viewModal')).show();
    } catch (e) { SL.toast(e.error || 'Could not load application.', true); }
  }

  $('hBody').addEventListener('click', async (ev) => {
    const v = ev.target.closest('[data-view]'), d = ev.target.closest('[data-del]');
    if (v) view(v.dataset.view);
    if (d && confirm(`Delete application #${d.dataset.del}? This cannot be undone.`)) {
      try { await SL.api('/api/applications/' + d.dataset.del, { method: 'DELETE' }); SL.toast('Application deleted.'); load(); }
      catch (e) { SL.toast(e.error || 'Delete failed.', true); }
    }
  });
  document.querySelectorAll('th.sortable').forEach(th => th.addEventListener('click', () => {
    const k = th.dataset.sort; state.order = (state.sort === k && state.order === 'desc') ? 'asc' : 'desc'; state.sort = k;
    document.querySelectorAll('th.sortable').forEach(t => { t.style.color = ''; t.textContent = t.textContent.replace(/ [▲▼]$/, ''); });
    th.style.color = 'var(--blue)'; th.textContent += state.order === 'asc' ? ' ▲' : ' ▼';
    load();
  }));
  ['fRisk', 'fPred', 'fFrom', 'fTo'].forEach(id => $(id).addEventListener('change', load));
  $('fQ').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 250); });
  $('fReset').addEventListener('click', () => { ['fQ', 'fRisk', 'fPred', 'fFrom', 'fTo'].forEach(id => $(id).value = ''); load(); });
  load();
})();
