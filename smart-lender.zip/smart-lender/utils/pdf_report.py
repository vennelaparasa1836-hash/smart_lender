"""PDF report generation with ReportLab (₹ rendered via bundled DejaVu Sans)."""
import io
import json
import os

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

from utils.config import BASE_DIR
from utils.formatting import inr

_FONT_DIR = os.path.join(BASE_DIR, "static", "fonts")
pdfmetrics.registerFont(TTFont("SL", os.path.join(_FONT_DIR, "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("SL-Bold", os.path.join(_FONT_DIR, "DejaVuSans-Bold.ttf")))

NAVY, BLUE, GREY = colors.HexColor("#0b1f3a"), colors.HexColor("#2563eb"), colors.HexColor("#64748b")
GREEN, RED = colors.HexColor("#059669"), colors.HexColor("#dc2626")

DISCLAIMER = ("This report is generated using a Machine Learning model and is intended to support "
              "financial assessment. It does not constitute automatic loan approval or rejection.")


def _p(text, size=10, bold=False, color=NAVY, align=0, leading=None):
    return Paragraph(text, ParagraphStyle("x", fontName="SL-Bold" if bold else "SL", fontSize=size,
                                          textColor=color, alignment=align,
                                          leading=leading or size * 1.35))


def _section(title, rows):
    data = [[_p(f"<b>{title}</b>", 11, True, colors.white), ""]]
    data += [[_p(k, 9.5, color=GREY), _p(str(v), 9.5)] for k, v in rows]
    t = Table(data, colWidths=[62 * mm, 108 * mm])
    t.setStyle(TableStyle([
        ("SPAN", (0, 0), (1, 0)), ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
        ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#e2e8f0")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    return t


def build_report(app) -> bytes:
    """app = sqlite3.Row from the application table."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=16 * mm, bottomMargin=16 * mm,
                            title=f"Loan Risk Assessment Report #{app['id']}", author="Smart Lender")
    repay = app["prediction"] == "Likely to Repay"
    accent = GREEN if repay else RED

    story = [
        _p("SMART LENDER", 22, True, BLUE),
        _p("Loan Risk Assessment Report", 14, True),
        _p(f"Application ID: {app['id']}  ·  Date: {app['created_at'][:10]}", 9, color=GREY),
        Spacer(1, 6 * mm),
    ]

    result = Table([[_p("PREDICTION", 8, True, GREY), _p("RISK LEVEL", 8, True, GREY),
                     _p("MODEL USED", 8, True, GREY)],
                    [_p(app["prediction"].upper(), 14, True, accent),
                     _p(app["risk_level"].upper(), 14, True, accent),
                     _p(app["model_used"], 14, True)]], colWidths=[62 * mm, 54 * mm, 54 * mm])
    result.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1, accent),
                                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
                                ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                                ("LEFTPADDING", (0, 0), (-1, -1), 10)]))
    story += [result, Spacer(1, 3 * mm)]

    if app["prediction_probability"] is not None:
        story += [_p(f"Model probability of repayment: <b>{app['prediction_probability'] * 100:.1f}%</b> "
                     "(model output score, not a guarantee).", 9.5), Spacer(1, 3 * mm)]

    story += [
        _section("Applicant Information", [
            ("Applicant name", app["applicant_name"]), ("Gender", app["gender"]),
            ("Marital status", app["marital_status"]), ("Dependents", app["dependents"]),
            ("Education", app["education"]), ("Employment status", app["self_employed"])]),
        Spacer(1, 4 * mm),
        _section("Loan Information", [
            ("Applicant income (monthly)", inr(app["applicant_income"])),
            ("Co-applicant income (monthly)", inr(app["coapplicant_income"])),
            ("Loan amount", inr(app["loan_amount"])), ("Loan term", f"{app['loan_term']} months"),
            ("Property area", app["property_area"])]),
        Spacer(1, 4 * mm),
        _section("Credit Information", [("Credit history", app["credit_history"])]),
        Spacer(1, 4 * mm),
    ]

    expl = json.loads(app["explanation_json"]) if app["explanation_json"] else None
    if expl and expl.get("features"):
        rows = []
        for f in expl["features"]:
            tail = f"  ({f['direction']})" if f.get("direction") else ""
            rows.append((f["feature"], f"{f['importance'] * 100:.1f}% of explained effect{tail}"))
        story += [_section("Important Features", rows),
                  _p(f"Method: {expl['method']}", 8.5, color=GREY), Spacer(1, 4 * mm)]

    story += [Spacer(1, 2 * mm), _p(f"<b>Disclaimer:</b> {DISCLAIMER}", 8.5, color=GREY)]
    doc.build(story)
    return buf.getvalue()
