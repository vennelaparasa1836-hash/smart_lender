"""Tiny .env loader (no extra dependency) + app configuration."""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_env(path=None):
    path = path or os.path.join(BASE_DIR, ".env")
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()

SECRET_KEY = os.environ.get("SECRET_KEY")
DATABASE_PATH = os.path.join(BASE_DIR, os.environ.get("DATABASE_PATH", "database/smart_lender.db"))
SEED_EMAIL = os.environ.get("SEED_EMAIL", "officer@smartlender.com")
SEED_PASSWORD = os.environ.get("SEED_PASSWORD", "Smart@1234")
DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"
PORT = int(os.environ.get("PORT", "5000"))
