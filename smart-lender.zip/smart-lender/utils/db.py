"""SQLite helpers (standard library only)."""
import os
import sqlite3

from utils.config import DATABASE_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS application (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES user(id) ON DELETE CASCADE,
    applicant_name TEXT NOT NULL,
    gender TEXT NOT NULL,
    marital_status TEXT NOT NULL,
    dependents TEXT NOT NULL,
    education TEXT NOT NULL,
    self_employed TEXT NOT NULL,
    applicant_income REAL NOT NULL,
    coapplicant_income REAL NOT NULL,
    loan_amount REAL NOT NULL,
    loan_term INTEGER NOT NULL,
    credit_history TEXT NOT NULL,
    property_area TEXT NOT NULL,
    prediction TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    model_used TEXT NOT NULL,
    prediction_probability REAL,          -- NULL when the model gives none (never faked)
    explanation_json TEXT,                -- NULL when no explanation was produced
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_app_user ON application(user_id, created_at);
"""


def connect():
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with connect() as conn:
        conn.executescript(SCHEMA)


def query(sql, args=(), one=False):
    conn = connect()
    try:
        rows = conn.execute(sql, args).fetchall()
    finally:
        conn.close()
    return (rows[0] if rows else None) if one else rows


def execute(sql, args=()):
    conn = connect()
    try:
        cur = conn.execute(sql, args)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()
