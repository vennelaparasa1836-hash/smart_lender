"""Server-side validation for every API input."""
import re

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'\-]{1,79}$")

GENDERS = {"Male", "Female", "Other"}
MARITAL = {"Married", "Single"}
DEPENDENTS = {"0", "1", "2", "3+"}
EDUCATION = {"Graduate", "Not Graduate"}
EMPLOYMENT = {"Salaried", "Self-employed"}
CREDIT = {"Good", "Poor", "Not Available"}
AREAS = {"Urban", "Semiurban", "Rural"}

MAX_INCOME = 10_000_000          # per month, INR
MAX_LOAN = 500_000_000           # INR


def _num(data, key, errors, label, minimum=0.0, maximum=None, required=True, integer=False):
    raw = data.get(key)
    if raw is None or str(raw).strip() == "":
        if required:
            errors[key] = f"{label} is required."
        return None
    try:
        val = float(str(raw).replace(",", ""))
    except ValueError:
        errors[key] = f"{label} must be a number."
        return None
    if val != val or val in (float("inf"), float("-inf")):
        errors[key] = f"{label} must be a valid number."
        return None
    if val < 0:
        errors[key] = f"{label} cannot be negative."
        return None
    if val < minimum:
        errors[key] = f"{label} must be at least {minimum:g}."
        return None
    if maximum is not None and val > maximum:
        errors[key] = f"{label} looks too large (max {maximum:,.0f})."
        return None
    if integer:
        if val != int(val):
            errors[key] = f"{label} must be a whole number."
            return None
        return int(val)
    return val


def _choice(data, key, allowed, errors, label):
    val = str(data.get(key, "")).strip()
    if not val:
        errors[key] = f"{label} is required."
    elif val not in allowed:
        errors[key] = f"Please choose a valid {label.lower()}."
    return val


def validate_prediction(data):
    """Returns (clean_dict, errors_dict)."""
    errors = {}
    data = data or {}
    name = str(data.get("applicant_name", "")).strip()
    if not name:
        errors["applicant_name"] = "Applicant name is required."
    elif not NAME_RE.match(name):
        errors["applicant_name"] = "Enter a valid name (letters, spaces, . ' - only)."

    clean = {
        "applicant_name": name,
        "gender": _choice(data, "gender", GENDERS, errors, "Gender"),
        "marital_status": _choice(data, "marital_status", MARITAL, errors, "Marital status"),
        "dependents": _choice(data, "dependents", DEPENDENTS, errors, "Dependents"),
        "education": _choice(data, "education", EDUCATION, errors, "Education"),
        "self_employed": _choice(data, "self_employed", EMPLOYMENT, errors, "Employment status"),
        "applicant_income": _num(data, "applicant_income", errors, "Applicant income",
                                 minimum=1, maximum=MAX_INCOME),
        "coapplicant_income": _num(data, "coapplicant_income", errors, "Co-applicant income",
                                   maximum=MAX_INCOME, required=False) or 0.0,
        "loan_amount": _num(data, "loan_amount", errors, "Loan amount",
                            minimum=1000, maximum=MAX_LOAN),
        "loan_term": _num(data, "loan_term", errors, "Loan term", minimum=6, maximum=480,
                          integer=True),
        "credit_history": _choice(data, "credit_history", CREDIT, errors, "Credit history"),
        "property_area": _choice(data, "property_area", AREAS, errors, "Property area"),
    }
    return clean, errors


def validate_register(data):
    errors, data = {}, data or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    pw, pw2 = str(data.get("password", "")), str(data.get("confirm_password", ""))
    if not name:
        errors["name"] = "Full name is required."
    elif not NAME_RE.match(name):
        errors["name"] = "Enter a valid name."
    if not email:
        errors["email"] = "Email is required."
    elif not EMAIL_RE.match(email) or len(email) > 120:
        errors["email"] = "Enter a valid email address."
    errors.update(password_errors(pw, "password"))
    if "password" not in errors and pw != pw2:
        errors["confirm_password"] = "Passwords do not match."
    return {"name": name, "email": email, "password": pw}, errors


def password_errors(pw, key):
    if len(pw) < 8:
        return {key: "Password must be at least 8 characters."}
    if len(pw) > 128:
        return {key: "Password is too long."}
    if not (re.search(r"[A-Za-z]", pw) and re.search(r"\d", pw)):
        return {key: "Password must contain letters and numbers."}
    return {}
