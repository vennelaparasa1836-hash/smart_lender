"""Starter account + sample applications.

Every record is created by running the SAME trained model used by the live app, so
predictions, probabilities and explanations are real model output.
The applicants are sample entries, not real customers.
"""
import json
import random
from datetime import datetime, timedelta

from werkzeug.security import generate_password_hash

from ml import predict as ml_predict
from ml.explain import explain
from utils import db
from utils.config import SEED_EMAIL, SEED_PASSWORD

# (name, gender, marital, dependents, education, employment, applicant_inc, coapp_inc,
#  loan_amount, term, credit, area)   -- all incomes are monthly, in INR
SAMPLE_APPLICANTS = [
    ("Rahul", "Male", "Married", "1", "Graduate", "Salaried", 50000, 20000, 500000, 360, "Good", "Urban"),
    ("Priya Sharma", "Female", "Single", "0", "Graduate", "Salaried", 62000, 0, 800000, 240, "Good", "Semiurban"),
    ("Arjun Mehta", "Male", "Married", "2", "Graduate", "Self-employed", 45000, 18000, 1800000, 360, "Poor", "Urban"),
    ("Sneha Iyer", "Female", "Married", "0", "Graduate", "Salaried", 78000, 35000, 1500000, 300, "Good", "Urban"),
    ("Vikram Singh", "Male", "Married", "3+", "Not Graduate", "Self-employed", 28000, 12000, 2200000, 360, "Poor", "Rural"),
    ("Ananya Reddy", "Female", "Single", "0", "Graduate", "Salaried", 55000, 0, 600000, 180, "Good", "Semiurban"),
    ("Karthik Nair", "Male", "Single", "0", "Graduate", "Salaried", 41000, 0, 450000, 240, "Good", "Urban"),
    ("Meera Joshi", "Female", "Married", "1", "Not Graduate", "Salaried", 32000, 16000, 900000, 360, "Good", "Rural"),
    ("Rohit Gupta", "Male", "Married", "2", "Graduate", "Self-employed", 95000, 40000, 3500000, 360, "Good", "Urban"),
    ("Divya Menon", "Female", "Single", "0", "Graduate", "Salaried", 36000, 0, 1400000, 360, "Poor", "Semiurban"),
    ("Suresh Kumar", "Male", "Married", "3+", "Not Graduate", "Salaried", 24000, 9000, 1300000, 360, "Poor", "Rural"),
    ("Pooja Desai", "Female", "Married", "1", "Graduate", "Salaried", 68000, 30000, 1200000, 300, "Good", "Semiurban"),
    ("Amit Verma", "Male", "Single", "0", "Not Graduate", "Self-employed", 30000, 0, 700000, 240, "Not Available", "Urban"),
    ("Neha Kapoor", "Female", "Married", "2", "Graduate", "Salaried", 85000, 45000, 2500000, 360, "Good", "Urban"),
    ("Sanjay Patil", "Male", "Married", "2", "Graduate", "Salaried", 38000, 14000, 1600000, 360, "Poor", "Semiurban"),
    ("Kavya Rao", "Female", "Single", "0", "Graduate", "Salaried", 47000, 0, 550000, 180, "Good", "Urban"),
    ("Manoj Tiwari", "Male", "Married", "1", "Not Graduate", "Self-employed", 26000, 10000, 1900000, 360, "Poor", "Rural"),
    ("Lakshmi Pillai", "Female", "Married", "0", "Graduate", "Salaried", 59000, 25000, 950000, 240, "Good", "Semiurban"),
    ("Deepak Chawla", "Male", "Single", "0", "Graduate", "Self-employed", 72000, 0, 2800000, 360, "Good", "Urban"),
    ("Farah Khan", "Female", "Married", "2", "Graduate", "Salaried", 51000, 22000, 1100000, 300, "Good", "Urban"),
    ("Naveen Babu", "Male", "Married", "3+", "Not Graduate", "Salaried", 22000, 8000, 800000, 240, "Not Available", "Rural"),
    ("Isha Banerjee", "Female", "Single", "0", "Graduate", "Salaried", 64000, 0, 750000, 240, "Good", "Semiurban"),
    ("Gaurav Saxena", "Male", "Married", "1", "Graduate", "Salaried", 43000, 19000, 2000000, 360, "Poor", "Urban"),
    ("Tanvi Kulkarni", "Female", "Married", "0", "Graduate", "Salaried", 70000, 28000, 1000000, 300, "Good", "Semiurban"),
]


def ensure_seed_user() -> int:
    row = db.query("SELECT id FROM user WHERE email = ?", (SEED_EMAIL,), one=True)
    if row:
        return row["id"]
    return db.execute("INSERT INTO user (name, email, password) VALUES (?, ?, ?)",
                      ("Credit Officer", SEED_EMAIL, generate_password_hash(SEED_PASSWORD)))


FIELDS = ["applicant_name", "gender", "marital_status", "dependents", "education", "self_employed",
          "applicant_income", "coapplicant_income", "loan_amount", "loan_term", "credit_history",
          "property_area"]
# 5 sample records every new account gets (indices into SAMPLE_APPLICANTS): a mix of profiles
STARTER_SET = [0, 1, 2, 4, 3]


def _insert_sample(uid, a, when, pipe):
    form = dict(zip(FIELDS, a))
    res = ml_predict.predict(form)
    expl = explain(pipe, res["frame"])
    db.execute(
        """INSERT INTO application (user_id, applicant_name, gender, marital_status, dependents,
           education, self_employed, applicant_income, coapplicant_income, loan_amount, loan_term,
           credit_history, property_area, prediction, risk_level, model_used,
           prediction_probability, explanation_json, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (uid, form["applicant_name"], form["gender"], form["marital_status"],
         form["dependents"], form["education"], form["self_employed"], form["applicant_income"],
         form["coapplicant_income"], form["loan_amount"], form["loan_term"], form["credit_history"],
         form["property_area"], res["prediction"], res["risk_level"], res["model_used"],
         res["probability"], json.dumps(expl) if expl else None, when.strftime("%Y-%m-%d %H:%M:%S")))


def seed_starter_records(uid) -> int:
    """Give one account 5 sample records (real model output), dated over the last days."""
    pipe, _ = ml_predict.load_selected()
    now = datetime.now()
    offsets = [timedelta(minutes=20), timedelta(hours=3), timedelta(days=1, hours=2),
               timedelta(days=3, hours=5), timedelta(days=6, hours=1)]
    for idx, off in zip(STARTER_SET, offsets):
        _insert_sample(uid, SAMPLE_APPLICANTS[idx], now - off, pipe)
    return len(STARTER_SET)


def seed_sample_data(force=False) -> int:
    """Full 24-record set for the pre-created starter account (only if it has none)."""
    uid = ensure_seed_user()
    existing = db.query("SELECT COUNT(*) c FROM application WHERE user_id = ?", (uid,), one=True)["c"]
    if existing and not force:
        return 0
    if force:
        db.execute("DELETE FROM application WHERE user_id = ?", (uid,))
    pipe, _ = ml_predict.load_selected()
    rng = random.Random(7)
    now = datetime.now()
    n = len(SAMPLE_APPLICANTS)
    for i, a in enumerate(SAMPLE_APPLICANTS):
        if i >= n - 5:   # last 5 dated today
            when = now - timedelta(minutes=rng.randint(5, 400))
        else:
            when = now - timedelta(days=rng.randint(1, 170), hours=rng.randint(0, 20))
        _insert_sample(uid, a, when, pipe)
    return n
