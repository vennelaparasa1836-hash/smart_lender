"""Formatting helpers (Indian digit grouping, e.g. 5,00,000)."""


def inr(value, decimals=0):
    """Format a number as ₹ with Indian digit grouping."""
    if value is None:
        return "—"
    neg = value < 0
    value = abs(float(value))
    whole, _, frac = f"{value:.{decimals}f}".partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        whole = ",".join(parts + [tail])
    out = "₹" + whole + (("." + frac) if decimals else "")
    return "-" + out if neg else out
