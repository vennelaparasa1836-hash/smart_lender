"""Prediction explanation.

Primary method  : SHAP-style per-prediction contributions computed by XGBoost itself
                  (booster.predict(..., pred_contribs=True) is exact TreeSHAP).
                  One-hot columns are summed back to the original input feature.
Fallback method : the model's global feature_importances_ (clearly labelled as such).
Nothing here is hand-written: if neither method works, no explanation is returned.
"""
import numpy as np

from ml.preprocess import CATEGORICAL, DISPLAY_NAMES, NUMERIC


def _group_names(prep):
    """Map every transformed column back to its original feature name."""
    out = list(NUMERIC)
    ohe = prep.named_transformers_["cat"].named_steps["onehot"]
    for col, cats in zip(CATEGORICAL, ohe.categories_):
        out += [col] * len(cats)
    return out


def explain(pipe, frame, top_n=6):
    try:
        prep, model = pipe.named_steps["prep"], pipe.named_steps["model"]
        groups = _group_names(prep)
        Xt = prep.transform(frame)
    except Exception:
        return None

    # 1) per-prediction contributions (XGBoost TreeSHAP)
    try:
        import xgboost as xgb
        contribs = model.get_booster().predict(xgb.DMatrix(Xt), pred_contribs=True)[0][:-1]
        agg = {}
        for g, v in zip(groups, contribs):
            agg[g] = agg.get(g, 0.0) + float(v)
        total = sum(abs(v) for v in agg.values()) or 1.0
        items = sorted(agg.items(), key=lambda kv: abs(kv[1]), reverse=True)[:top_n]
        return {
            "method": "SHAP values (XGBoost TreeSHAP)",
            "kind": "local",
            "features": [{
                "feature": DISPLAY_NAMES[g],
                "importance": round(abs(v) / total, 4),
                "direction": "towards repayment" if v > 0 else "towards default",
            } for g, v in items],
        }
    except Exception:
        pass

    # 2) global feature importance fallback
    if hasattr(model, "feature_importances_"):
        agg = {}
        for g, v in zip(groups, model.feature_importances_):
            agg[g] = agg.get(g, 0.0) + float(v)
        total = sum(agg.values()) or 1.0
        items = sorted(agg.items(), key=lambda kv: kv[1], reverse=True)[:top_n]
        return {
            "method": "Model feature importance (global, not specific to this applicant)",
            "kind": "global",
            "features": [{"feature": DISPLAY_NAMES[g], "importance": round(v / total, 4),
                          "direction": None} for g, v in items],
        }
    return None
