"""Preprocessing shared by training and prediction.

The ColumnTransformer is placed INSIDE each model's sklearn Pipeline, so imputers,
scalers and encoders are fitted on the training split only (no data leakage).
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUMERIC = ["ApplicantIncome", "CoapplicantIncome", "LoanAmount",
           "Loan_Amount_Term", "Credit_History"]
CATEGORICAL = ["Gender", "Married", "Dependents", "Education",
               "Self_Employed", "Property_Area"]
FEATURES = CATEGORICAL + NUMERIC
TARGET = "Loan_Status"

# Friendly names shown in the UI / reports
DISPLAY_NAMES = {
    "Gender": "Gender", "Married": "Marital Status", "Dependents": "Dependents",
    "Education": "Education", "Self_Employed": "Employment Status",
    "Property_Area": "Property Area", "ApplicantIncome": "Applicant Income",
    "CoapplicantIncome": "Co-applicant Income", "LoanAmount": "Loan Amount",
    "Loan_Amount_Term": "Loan Term", "Credit_History": "Credit History",
}


def build_preprocessor(scale: bool) -> ColumnTransformer:
    """scale=True for KNN (distance based); False for tree-based models."""
    num_steps = [("impute", SimpleImputer(strategy="median"))]
    if scale:
        num_steps.append(("scale", StandardScaler()))
    return ColumnTransformer([
        ("num", Pipeline(num_steps), NUMERIC),
        ("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]), CATEGORICAL),
    ])


def load_and_clean(df: pd.DataFrame):
    """Light cleaning that does not learn anything from the data."""
    df = df.copy()
    df["Dependents"] = df["Dependents"].astype("string").str.strip().replace({"3": "3+"})
    for c in CATEGORICAL:
        df[c] = df[c].astype("object").where(df[c].notna(), np.nan)
    X = df[FEATURES]
    y = (df[TARGET] == "Y").astype(int)  # 1 = Likely to Repay, 0 = Likely to Default
    return X, y


def form_to_frame(data: dict) -> pd.DataFrame:
    """Convert validated web-form values to the model's feature layout."""
    credit = {"Good": 1.0, "Poor": 0.0}.get(data["credit_history"], np.nan)  # Not Available -> NaN
    row = {
        "Gender": data["gender"],
        "Married": "Yes" if data["marital_status"] == "Married" else "No",
        "Dependents": data["dependents"],
        "Education": data["education"],
        "Self_Employed": "Yes" if data["self_employed"] == "Self-employed" else "No",
        "ApplicantIncome": float(data["applicant_income"]),
        "CoapplicantIncome": float(data["coapplicant_income"]),
        "LoanAmount": float(data["loan_amount"]),
        "Loan_Amount_Term": float(data["loan_term"]),
        "Credit_History": credit,
        "Property_Area": data["property_area"],
    }
    return pd.DataFrame([row], columns=FEATURES)
