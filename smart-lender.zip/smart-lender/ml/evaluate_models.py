"""Metric calculation. Every number shown in the app comes from here."""
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)


def evaluate(pipeline, X_train, y_train, X_test, y_test) -> dict:
    """Metrics for the positive class (1 = Likely to Repay)."""
    pred_test = pipeline.predict(X_test)
    pred_train = pipeline.predict(X_train)
    tn, fp, fn, tp = confusion_matrix(y_test, pred_test, labels=[0, 1]).ravel()
    return {
        "train_accuracy": round(float(accuracy_score(y_train, pred_train)), 4),
        "test_accuracy": round(float(accuracy_score(y_test, pred_test)), 4),
        "precision": round(float(precision_score(y_test, pred_test, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, pred_test, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, pred_test, zero_division=0)), 4),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def select_best(results: dict) -> str:
    """Best model = highest test accuracy; ties broken by F1 then by name order."""
    return max(results, key=lambda k: (results[k]["test_accuracy"], results[k]["f1_score"]))
