"""Loads the selected saved model and produces a prediction."""
import json
import os

import joblib

from ml.preprocess import form_to_frame

SAVED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "saved_models")
_cache = {}


def models_ready() -> bool:
    return os.path.exists(os.path.join(SAVED, "metrics.json"))


def load_metrics() -> dict:
    with open(os.path.join(SAVED, "metrics.json")) as f:
        return json.load(f)


def load_selected():
    if "pipe" not in _cache:
        m = load_metrics()
        _cache["meta"] = m
        _cache["pipe"] = joblib.load(os.path.join(SAVED, f"{m['selected_model']}_model.pkl"))
    return _cache["pipe"], _cache["meta"]


def reset_cache():
    _cache.clear()


def predict(form: dict) -> dict:
    """form = validated web-form dict. Returns prediction, risk level, probability."""
    pipe, meta = load_selected()
    X = form_to_frame(form)
    cls = int(pipe.predict(X)[0])
    result = {
        "prediction": "Likely to Repay" if cls == 1 else "Likely to Default",
        "risk_level": "Low Risk" if cls == 1 else "High Risk",
        "model_used": meta["selected_label"],
        "probability": None,
        "frame": X,
    }
    # Probability only if the model really provides one
    if hasattr(pipe, "predict_proba"):
        proba = pipe.predict_proba(X)[0]
        classes = list(pipe.classes_)
        if 1 in classes:
            result["probability"] = round(float(proba[classes.index(1)]), 4)  # P(repay)
    return result
