"""Train, compare and save the four Smart Lender models.

Run:  python ml/train_models.py
"""
import json
import os
import sys
from datetime import datetime, timezone

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ml.evaluate_models import evaluate, select_best  # noqa: E402
from ml.preprocess import build_preprocessor, load_and_clean  # noqa: E402

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data", "loan_dataset.csv")
OUT = os.path.join(BASE, "ml", "saved_models")
RANDOM_STATE = 42

MODEL_LABELS = {
    "decision_tree": "Decision Tree",
    "random_forest": "Random Forest",
    "knn": "KNN",
    "xgboost": "XGBoost",
}


def make_models():
    from xgboost import XGBClassifier  # imported here for a clear error if missing
    return {
        "decision_tree": Pipeline([
            ("prep", build_preprocessor(scale=False)),
            ("model", DecisionTreeClassifier(max_depth=4, min_samples_leaf=10,
                                             random_state=RANDOM_STATE))]),
        "random_forest": Pipeline([
            ("prep", build_preprocessor(scale=False)),
            ("model", RandomForestClassifier(n_estimators=200, max_depth=6,
                                             min_samples_leaf=5,
                                             random_state=RANDOM_STATE))]),
        "knn": Pipeline([
            ("prep", build_preprocessor(scale=True)),  # KNN needs scaled features
            ("model", KNeighborsClassifier(n_neighbors=11))]),
        "xgboost": Pipeline([
            ("prep", build_preprocessor(scale=False)),
            ("model", XGBClassifier(n_estimators=150, max_depth=3, learning_rate=0.08,
                                    subsample=0.9, colsample_bytree=0.9,
                                    eval_metric="logloss", random_state=RANDOM_STATE))]),
    }


def main():
    print("1. Loading dataset:", DATA)
    df = pd.read_csv(DATA)

    print("2. Inspecting data")
    print("   shape:", df.shape)
    print("   missing values per column:\n", df.isna().sum()[df.isna().sum() > 0].to_string())
    print("   target distribution:\n", df["Loan_Status"].value_counts().to_string())

    print("3-5. Cleaning + preparing features/target (imputing/encoding happen inside pipelines)")
    X, y = load_and_clean(df)

    print("6. Train/test split (80/20, stratified, random_state=42)")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE)

    results, models = {}, make_models()
    os.makedirs(OUT, exist_ok=True)
    for i, (key, pipe) in enumerate(models.items(), start=7):
        print(f"{i}. Training {MODEL_LABELS[key]}")
        pipe.fit(X_train, y_train)
        results[key] = evaluate(pipe, X_train, y_train, X_test, y_test)
        joblib.dump(pipe, os.path.join(OUT, f"{key}_model.pkl"))
        r = results[key]
        print(f"   train acc {r['train_accuracy']:.3f} | test acc {r['test_accuracy']:.3f} | "
              f"precision {r['precision']:.3f} | recall {r['recall']:.3f} | f1 {r['f1_score']:.3f}")

    best = select_best(results)
    print(f"11-12. Best model on test data: {MODEL_LABELS[best]}")

    payload = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "dataset_rows": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "random_state": RANDOM_STATE,
        "positive_class": "Likely to Repay",
        "selected_model": best,
        "selected_label": MODEL_LABELS[best],
        "labels": MODEL_LABELS,
        "models": results,
    }
    with open(os.path.join(OUT, "metrics.json"), "w") as f:
        json.dump(payload, f, indent=2)
    print("13-14. Saved models + metrics.json in", OUT)


if __name__ == "__main__":
    main()
