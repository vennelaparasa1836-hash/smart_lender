"""
Generates data/loan_dataset.csv

IMPORTANT: This is a SYNTHETIC dataset created for this academic project, using the
same columns as the well-known "Loan Prediction" dataset layout. It does not
contain real customers. If you have the real dataset (e.g. from Kaggle), simply
replace data/loan_dataset.csv with it (same column names, Loan_Status = Y/N)
and re-run:  python ml/train_models.py

Amounts are in Indian Rupees (INR): incomes are MONTHLY, LoanAmount is TOTAL.
"""
import os
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 900

gender = rng.choice(["Male", "Female", "Other"], N, p=[0.78, 0.20, 0.02])
married = rng.choice(["Yes", "No"], N, p=[0.63, 0.37])
dependents = rng.choice(["0", "1", "2", "3+"], N, p=[0.57, 0.17, 0.17, 0.09])
education = rng.choice(["Graduate", "Not Graduate"], N, p=[0.78, 0.22])
self_emp = rng.choice(["No", "Yes"], N, p=[0.86, 0.14])
area = rng.choice(["Urban", "Semiurban", "Rural"], N, p=[0.33, 0.38, 0.29])

base = np.where(education == "Graduate", 52000, 36000) * np.where(self_emp == "Yes", 1.15, 1.0)
app_income = np.round(rng.lognormal(mean=np.log(base), sigma=0.45)).astype(int)
co_income = np.where(
    (married == "Yes") & (rng.random(N) < 0.65),
    np.round(rng.lognormal(mean=np.log(22000), sigma=0.5)),
    0,
).astype(int)

total_income = app_income + co_income
loan_amount = np.round(total_income * rng.uniform(4, 16, N) / 1000) * 1000
loan_amount = np.clip(loan_amount, 50000, 3000000).astype(int)
term = rng.choice([120, 180, 240, 300, 360, 480], N, p=[0.03, 0.05, 0.05, 0.05, 0.80, 0.02])

credit = (rng.random(N) < 0.82).astype(float)  # 1 = good, 0 = poor

# latent repayment score (credit history dominates, as in real lending data)
ratio = loan_amount / np.maximum(total_income, 1)
z = (
    -0.4
    + 3.0 * credit
    - 0.12 * (ratio - 9)
    + 0.35 * (area == "Semiurban")
    + 0.15 * (married == "Yes")
    + 0.15 * (education == "Graduate")
    - 0.10 * (dependents == "3+")
    + rng.normal(0, 1.25, N)
)
status = np.where(z > 0.9, "Y", "N")

df = pd.DataFrame({
    "Loan_ID": [f"LP{100000 + i}" for i in range(N)],
    "Gender": gender,
    "Married": married,
    "Dependents": dependents,
    "Education": education,
    "Self_Employed": self_emp,
    "ApplicantIncome": app_income,
    "CoapplicantIncome": co_income,
    "LoanAmount": loan_amount,
    "Loan_Amount_Term": term,
    "Credit_History": credit,
    "Property_Area": area,
    "Loan_Status": status,
})

# realistic missing values (the pipeline must handle them)
for col, frac in [("Gender", 0.02), ("Married", 0.005), ("Dependents", 0.025),
                  ("Self_Employed", 0.05), ("LoanAmount", 0.035),
                  ("Loan_Amount_Term", 0.02), ("Credit_History", 0.08)]:
    idx = rng.choice(N, int(N * frac), replace=False)
    df.loc[idx, col] = np.nan

out = os.path.join(os.path.dirname(__file__), "loan_dataset.csv")
df.to_csv(out, index=False)
print(f"Wrote {out}: {df.shape[0]} rows, repay rate = {(df.Loan_Status == 'Y').mean():.1%}")
